var scrapper = require('scrapper');


scrapper.get('https://www.instagram.com/mcm_indonesia/?__a=1', function($){
    console.log($('body').text())
}, {text: 'NodeJS!'}, {'User-Agent': 'Googlebot'});
